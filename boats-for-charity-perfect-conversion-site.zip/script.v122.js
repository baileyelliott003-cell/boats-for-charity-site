// Boats for Charity — form validation, mobile nav, and conversion helpers
document.addEventListener('DOMContentLoaded', () => {
  const toast = document.getElementById('toast');
  const url = new URL(window.location.href);
  if (toast && url.searchParams.get('submitted') === '1') {
    toast.hidden = false;
    setTimeout(() => toast.hidden = true, 4500);
  }

  const form = document.getElementById('donationForm');
  const msg = document.querySelector('.form-msg');
  if (form && form.hasAttribute('data-netlify')) {
    form.addEventListener('submit', (e) => {
      const required = ['name','phone','email','boat','location'];
      for (const key of required) {
        const el = form.querySelector(`[name="${key}"]`);
        if (!el || !String(el.value || '').trim()) {
          e.preventDefault();
          if (msg) {
            msg.textContent = 'Please fill out your name, phone, email, boat type, and location.';
            msg.style.color = '#b91c1c';
          }
          if (el) el.focus();
          return;
        }
      }
      if (msg) {
        msg.textContent = 'Sending...';
        msg.style.color = '#5f6b7a';
      }
    });
  }

  const toggle = document.getElementById('menuToggle');
  const nav = document.getElementById('primaryNav');
  function setNavState(){
    if (!nav) return;
    if (window.innerWidth > 700) {
      nav.removeAttribute('hidden');
      if (toggle) toggle.setAttribute('aria-expanded','true');
    } else {
      nav.setAttribute('hidden','');
      if (toggle) toggle.setAttribute('aria-expanded','false');
    }
  }
  setNavState();
  window.addEventListener('resize', () => {
    clearTimeout(window.__navResizeTimer);
    window.__navResizeTimer = setTimeout(setNavState, 120);
  });
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.hasAttribute('hidden');
      if (open) {
        nav.removeAttribute('hidden');
        toggle.setAttribute('aria-expanded','true');
      } else {
        nav.setAttribute('hidden','');
        toggle.setAttribute('aria-expanded','false');
      }
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      if (window.innerWidth <= 700) {
        nav.setAttribute('hidden','');
        toggle.setAttribute('aria-expanded','false');
      }
    }));
  }
});
