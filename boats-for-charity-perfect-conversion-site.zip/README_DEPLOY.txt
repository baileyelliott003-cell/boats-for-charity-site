Boats for Charity — Conversion Optimized Build

Deploy:
1. Unzip this folder.
2. Drag the unzipped folder into Netlify Deploys or upload to your host.
3. Keep Netlify Forms enabled so donationForm submissions are captured.
4. Optional auto-reply: set RESEND_API_KEY and FROM_EMAIL in Netlify environment variables.

What changed:
- Rebuilt homepage as a direct-response landing page.
- Moved the lead form above the fold.
- Reduced the first ask to the fields needed to call the donor.
- Added sticky mobile Call / Donate bar.
- Rewrote copy around boat-owner pain points: won't sell, storage, inherited, non-running.
- Preserved SEO pages and sitemap.
- Kept the existing logo, favicon, Netlify config, and auto-reply function.
